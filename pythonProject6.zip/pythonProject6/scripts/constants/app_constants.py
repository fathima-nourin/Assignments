class EndPoints:
    api_calculate = "/calculate"
    add = "/add"
    subtract = "/subtract"
    multiply = "/multiply"
    divide = "/divide"
